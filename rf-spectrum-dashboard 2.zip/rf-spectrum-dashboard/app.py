import streamlit as st
import numpy as np
from typing import Tuple
import plotly.graph_objects as go
import plotly.express as px

from rf_simulation import (
    generate_rf_signal,
    compute_fft,
    apply_filter_freqdomain,
    detect_peaks,
)

st.set_page_config(page_title="RF Spectrum Dashboard", layout="wide")
st.title("RF Spectrum Dashboard (Interactive)")

# ---------- Sidebar ----------
with st.sidebar:
    # Header row with info popover
    cA, cB = st.columns([1,0.13])
    with cA: st.header("Signal parameters")
    with cB:
        with st.popover("ℹ️"):
            st.markdown("Sampling, duration, and noise for the synthetic RF signal. Carriers are pure tones summed with optional noise.")

    fs = st.number_input("Sampling rate (Hz)", min_value=1000, max_value=5_000_000, value=100_000, step=1000)
    duration = st.number_input("Duration (s)", min_value=0.01, max_value=5.0, value=0.5, step=0.01, format="%.2f")
    noise_std = st.number_input("Noise std (linear)", min_value=0.0, max_value=5.0, value=0.2, step=0.05)

    st.markdown("**Carriers**")
    carrier_freqs_str = st.text_input("Frequencies (Hz, comma separated)", value="1000, 5000, 12000")
    carrier_amps_str = st.text_input("Amplitudes (comma separated)", value="1.0, 0.8, 0.6")

    # Doppler section
    cD1, cD2 = st.columns([1,0.13])
    with cD1: st.header("Doppler")
    with cD2:
        with st.popover("ℹ️"):
            st.markdown("Apply frequency shift from relative radial velocity. Use **Manual** or enable **Satellite (LEO)** to compute a realistic radial component.")

    doppler_manual = st.checkbox("Manual Doppler", value=False)
    velocity_manual = st.number_input("Manual radial velocity (m/s)", value=0.0, step=1.0, format="%.2f")

    sat_mode = st.checkbox("Satellite (LEO) Doppler model", value=False)
    sat_speed_kms = st.number_input("Orbital speed (km/s)", min_value=0.0, max_value=10.0, value=7.5, step=0.1)
    sat_radial_factor = st.slider("Radial factor (toward=+1, away=-1)", min_value=-1.0, max_value=1.0, value=0.4, step=0.05)

    # Filtering section
    cF1, cF2 = st.columns([1,0.13])
    with cF1: st.header("Filtering")
    with cF2:
        with st.popover("ℹ️"):
            st.markdown("Frequency-domain mask: **lowpass**, **highpass**, or **bandpass**. Values are in Hz.")
    filt_mode = st.selectbox("Filter type", ["none","lowpass","highpass","bandpass"], index=0)
    f_low = st.number_input("Low cutoff (Hz)", min_value=0.0, value=0.0, step=100.0, format="%.2f")
    f_high = st.number_input("High cutoff (Hz)", min_value=0.0, value=0.0, step=100.0, format="%.2f")

    # Peaks
    cP1, cP2 = st.columns([1,0.13])
    with cP1: st.header("Peak detection")
    with cP2:
        with st.popover("ℹ️"):
            st.markdown("Simple local-max detector on |FFT| with threshold and minimum frequency separation.")
    peak_thresh = st.number_input("Magnitude threshold", min_value=0.0, value=0.2, step=0.05, format="%.2f")
    min_sep = st.number_input("Min separation (Hz)", min_value=0.0, value=200.0, step=50.0, format="%.2f")

    # Zoom
    cZ1, cZ2 = st.columns([1,0.13])
    with cZ1: st.header("Spectrum zoom")
    with cZ2:
        with st.popover("ℹ️"):
            st.markdown("Limit the frequency range shown. You can also zoom/pan directly on the plots.")
    zoom_range = st.slider("Freq range (Hz)", min_value=0, max_value=int(fs//2), value=(0, int(fs//2)), step=max(int(fs//200),1))

# ---------- Helpers ----------
def _parse_list(s): 
    return [float(p.strip()) for p in s.split(",") if p.strip()]

def _spectrogram(x: np.ndarray, fs: float, nperseg: int = 2048, noverlap: int = 1024) -> Tuple[np.ndarray,np.ndarray,np.ndarray]:
    # SciPy-free STFT
    n = len(x)
    nperseg = min(max(256, nperseg), n)
    noverlap = min(max(0, noverlap), nperseg-1)
    step = nperseg - noverlap
    starts = np.arange(0, n - nperseg + 1, step)
    w = np.hanning(nperseg)
    S_list = []
    for s in starts:
        seg = x[s:s+nperseg] * w
        X = np.fft.rfft(seg)
        S_list.append(np.abs(X))
    S = np.stack(S_list, axis=1) if S_list else np.zeros((nperseg//2 + 1, 0))
    times = (starts + nperseg/2) / fs
    freqs = np.fft.rfftfreq(nperseg, d=1.0/fs)
    return times, freqs, S

# ---------- Parse + simulate ----------
try:
    carrier_freqs = _parse_list(carrier_freqs_str)
    carrier_amps = _parse_list(carrier_amps_str)
except ValueError:
    st.error("Invalid carrier input"); st.stop()

if len(carrier_freqs)==0 or len(carrier_freqs)!=len(carrier_amps):
    st.error("Frequencies and amplitudes must match."); st.stop()

# Resolve Doppler velocity
velocity = 0.0
if doppler_manual:
    velocity = velocity_manual
elif sat_mode:
    velocity = (sat_speed_kms * 1000.0) * float(sat_radial_factor)  # m/s (positive toward)

t, x, eff_freqs = generate_rf_signal(
    fs, duration, carrier_freqs, carrier_amps,
    noise_std=noise_std,
    doppler_velocity_m_s=velocity
)

x_proc = x if filt_mode=="none" else apply_filter_freqdomain(
    x, fs, filt_mode,
    low_hz=f_low if filt_mode in ["lowpass","bandpass"] else None,
    high_hz=f_high if filt_mode in ["highpass","bandpass"] else None
)

freqs, mags = compute_fft(x_proc, fs)
peaks = detect_peaks(freqs, mags, threshold=peak_thresh, min_separation_hz=min_sep)

# ---------- Row 1: Time + Spectrum (Plotly: zoomable) ----------
c1, c2 = st.columns(2, gap="large")

with c1:
    r1a, r1b = st.columns([1,0.13])
    with r1a: st.subheader("Time domain")
    with r1b:
        with st.popover("ℹ️"):
            st.markdown("First ~20 ms of the signal. Use legend toggles and drag to zoom.")
    max_pts = min(len(t), int(fs * min(duration, 0.02)))
    fig_td = go.Figure()
    fig_td.add_trace(go.Scatter(x=t[:max_pts], y=x[:max_pts], mode="lines", name="Raw"))
    fig_td.add_trace(go.Scatter(x=t[:max_pts], y=x_proc[:max_pts], mode="lines", name="Processed"))
    fig_td.update_layout(xaxis_title="Time (s)", yaxis_title="Amplitude", height=300, margin=dict(l=20,r=10,t=10,b=10))
    st.plotly_chart(fig_td, use_container_width=True)

with c2:
    r1c, r1d = st.columns([1,0.13])
    with r1c: st.subheader("Frequency spectrum")
    with r1d:
        with st.popover("ℹ️"):
            st.markdown("|FFT| of the processed signal with peak markers.")
    x_min, x_max = zoom_range
    fig_sp = go.Figure()
    fig_sp.add_trace(go.Scatter(x=freqs, y=mags, mode="lines", name="|FFT|"))
    if peaks:
        fig_sp.add_trace(go.Scatter(
            x=[p[0] for p in peaks], y=[p[1] for p in peaks],
            mode="markers+text", text=[f"{p[0]:.0f} Hz" for p in peaks],
            textposition="top center", name="Peaks"
        ))
    fig_sp.update_layout(xaxis_title="Frequency (Hz)", yaxis_title="Magnitude", height=300, margin=dict(l=20,r=10,t=10,b=10))
    fig_sp.update_xaxes(range=[x_min, x_max])
    st.plotly_chart(fig_sp, use_container_width=True)

# ---------- Row 2: Spectrogram ----------
r2a, r2b = st.columns([1,0.13])
with r2a: st.subheader("Spectrogram (time–frequency)")
with r2b:
    with st.popover("ℹ️"):
        st.markdown("Short-time FFT heatmap (dB). Shows how energy evolves over time.")
times, f_s, S = _spectrogram(x_proc, fs, nperseg=2048, noverlap=1024)
if S.size == 0:
    st.info("Increase duration or sampling rate for spectrogram.")
else:
    SdB = 20.0 * np.log10(np.maximum(S, 1e-12))
    fig_spec = px.imshow(SdB, origin="lower", aspect="auto", x=times, y=f_s,
                         color_continuous_scale="Turbo",
                         labels=dict(x="Time (s)", y="Frequency (Hz)", color="Mag (dB)"))
    fig_spec.update_yaxes(range=[zoom_range[0], zoom_range[1]])
    fig_spec.update_layout(height=320, margin=dict(l=20,r=10,t=10,b=10))
    st.plotly_chart(fig_spec, use_container_width=True)

# ---------- Row 3: Cumulative Spectral Power ----------
r3a, r3b = st.columns([1,0.13])
with r3a: st.subheader("Cumulative spectral power")
with r3b:
    with st.popover("ℹ️"):
        st.markdown("Normalized cumulative sum of power vs. frequency. Reveals where most energy resides.")
power = mags**2
cum = np.cumsum(power)
if cum.size and cum[-1] > 0:
    cum /= cum[-1]
fig_cum = go.Figure()
fig_cum.add_trace(go.Scatter(x=freqs, y=cum, mode="lines", name="Cumulative power"))
fig_cum.update_layout(xaxis_title="Frequency (Hz)", yaxis_title="Fraction of total power",
                      height=300, margin=dict(l=20,r=10,t=10,b=10))
fig_cum.update_xaxes(range=[zoom_range[0], zoom_range[1]])
st.plotly_chart(fig_cum, use_container_width=True)

# ---------- Peaks table ----------
st.subheader("Detected peaks")
if peaks:
    st.dataframe({"Frequency (Hz)": [round(f,2) for f,_ in peaks],
                  "Magnitude": [round(m,4) for _,m in peaks]},
                 use_container_width=True)
else:
    st.info("No peaks above threshold.")

# ---------- Footer quick facts ----------
with st.expander("Run info"):
    st.write({
        "Effective carrier freqs (after Doppler)": [round(f, 3) for f in (carrier_freqs if velocity==0 else [])],
        "Sampling rate (Hz)": fs,
        "Duration (s)": duration,
        "Noise std": noise_std,
        "Doppler velocity used (m/s)": velocity,
        "Filter": {"mode": filt_mode, "low_hz": f_low, "high_hz": f_high}
    })
