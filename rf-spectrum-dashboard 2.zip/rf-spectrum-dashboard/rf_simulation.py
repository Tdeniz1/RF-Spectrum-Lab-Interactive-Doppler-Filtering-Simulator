import numpy as np

C_LIGHT = 299_792_458.0  # m/s

def generate_timebase(fs: float, duration: float):
    n = int(fs * duration)
    t = np.arange(n) / fs
    return t

def apply_doppler(freqs_hz, velocity_m_s):
    factor = 1.0 + (velocity_m_s / C_LIGHT)
    freqs_shifted = [max(0.0, f * factor) for f in freqs_hz]
    return freqs_shifted

def generate_rf_signal(fs: float,
                       duration: float,
                       carrier_freqs_hz,
                       carrier_amps,
                       noise_std: float = 0.1,
                       doppler_velocity_m_s: float = 0.0,
                       apply_doppler_to_all: bool = True):
    t = generate_timebase(fs, duration)

    if apply_doppler_to_all and abs(doppler_velocity_m_s) > 0:
        eff_freqs = apply_doppler(carrier_freqs_hz, doppler_velocity_m_s)
    else:
        eff_freqs = list(carrier_freqs_hz)

    rng = np.random.default_rng(42)
    x = np.zeros_like(t)
    phases = np.linspace(0.0, np.pi, num=len(eff_freqs), endpoint=False)

    for f, a, p in zip(eff_freqs, carrier_amps, phases):
        x += a * np.sin(2.0 * np.pi * f * t + p)

    if noise_std > 0:
        x += rng.normal(0.0, noise_std, size=t.shape)

    return t, x, eff_freqs

def compute_fft(x: np.ndarray, fs: float):
    n = len(x)
    w = np.hanning(n)
    xw = x * w
    X = np.fft.rfft(xw)
    freqs = np.fft.rfftfreq(n, d=1.0/fs)
    mags = (2.0 / np.sum(w)) * np.abs(X)
    return freqs, mags

def freq_mask(fs: float, n: int, mode: str, low_hz: float | None, high_hz: float | None):
    freqs = np.fft.rfftfreq(n, d=1.0/fs)
    mask = np.ones_like(freqs, dtype=bool)

    if mode == "none":
        return mask
    if mode == "lowpass":
        if low_hz is None: return mask
        return freqs <= float(low_hz)
    if mode == "highpass":
        if high_hz is None: return mask
        return freqs >= float(high_hz)
    if mode == "bandpass":
        if low_hz is None or high_hz is None: return mask
        lo, hi = sorted([float(low_hz), float(high_hz)])
        return (freqs >= lo) & (freqs <= hi)
    return mask

def apply_filter_freqdomain(x: np.ndarray, fs: float, mode: str,
                            low_hz: float | None = None,
                            high_hz: float | None = None):
    n = len(x)
    X = np.fft.rfft(x)
    m = freq_mask(fs, n, mode, low_hz, high_hz)
    X_filtered = np.where(m, X, 0.0)
    x_filt = np.fft.irfft(X_filtered, n=n)
    return x_filt

def detect_peaks(freqs: np.ndarray, mags: np.ndarray, threshold: float, min_separation_hz: float):
    if len(mags) < 3: return []
    left = mags[1:-1] > mags[:-2]
    right = mags[1:-1] >= mags[2:]
    cand = np.where(left & right)[0] + 1
    cand = cand[mags[cand] >= threshold]
    if cand.size == 0: return []
    selected = []
    for idx in cand[np.argsort(mags[cand])[::-1]]:
        f = freqs[idx]
        if all(abs(f - freqs[j]) >= min_separation_hz for j in selected):
            selected.append(idx)
    peaks = [(float(freqs[i]), float(mags[i])) for i in sorted(selected, key=lambda k: freqs[k])]
    return peaks
